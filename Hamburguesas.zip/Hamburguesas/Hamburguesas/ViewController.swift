//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Leonardo Estrada on 03/12/16.
//  Copyright © 2016 LEQ. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //Instancias
    let pais = ColeccionDePaises()
    let hamburguesa = ColeccionDeHamburguesas()
    let colores = Colores()

//Etiquetas de Pais y Hamburguesas
    @IBOutlet weak var muestraLosPaises: UILabel!
    
    @IBOutlet weak var muestraHamburguesas: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//Boton cambia color de fondo pais y hamburguesas
    @IBAction func cambiaPaisHamburguesa() {
        
    muestraLosPaises.text = pais.obtenPais()
    muestraHamburguesas.text = hamburguesa.obtenHamburguesa()
    
    let colorAleatorio = colores.regresaColorAleatorio()
        
    view.backgroundColor = colorAleatorio
    view.tintColor = colorAleatorio
        
    }

}


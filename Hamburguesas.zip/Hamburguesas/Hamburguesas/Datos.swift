//
//  Datos.swift
//  Hamburguesas
//
//  Created by Leonardo Estrada on 03/12/16.
//  Copyright © 2016 LEQ. All rights reserved.
//

import Foundation
import UIKit

//20 Paises
class ColeccionDePaises {
    
    let paises = ["Alemania","Australia","Brasil","Canada","Chile","Colombia","China","Corea del Norte","CostaRica","Cuba","Ecuador","España","Francia","Guatemala","India","Irak","Israel","Japon","Italia","Mexico"]
    
    init() {
        
    
    }
//Regresa Pais aleatorio
    func obtenPais()->String {
        let paisAleatorio = Int(arc4random()) % paises.count
        return paises[paisAleatorio]
    }
    
}

//20 Hamburguesas
class ColeccionDeHamburguesas {
    
    let hamburguesas = ["Clasica","Hawaiana","Mediterranea","Valenciana","Gorumet","Inglesa","Iberica","Japonesa","Mexicana","DobleCarne","Cubana","Italiana","Alemana","Integral","Vegetariana","Argentina","Española","Americana","4 Quesos","Black Angus"]
   
    init() {
    
    }
//Regresa hamburguesa aleatoria
    func obtenHamburguesa()->String {
        let hamburguesaAleatoria = Int(arc4random()) % hamburguesas.count
        return hamburguesas[hamburguesaAleatoria]
    }
}

struct Colores {
    
    let colores = [ UIColor(red:210/255.0, green: 90/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:40/255.0, green: 170/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 180/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:210/255.0, green: 190/255.0, blue: 5/255.0, alpha: 1),
                    
                    UIColor(red:120/255.0, green: 120/255.0, blue: 50/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 80/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 130/255.0, blue: 130/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 50/255.0, blue: 90/255.0, alpha: 1)]
    
    
    
    
    func regresaColorAleatorio()->UIColor {
        let posicion = Int(arc4random()) %  colores.count
        return colores[posicion]
}
}


